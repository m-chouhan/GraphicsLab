/*
 *  Contains Point3d class and wrappers for writing points to file(.svg)
 *  Author: Mahendra Chouhan(14CS60R12)
 * */

#include "Point3D.h"

double Rad(float Deg) 
{
	return (PI*Deg/180);
}
float Deg(float Rad)
{
      return (Rad*180/PI);
}

double normR(double val)
{
      if(val < 0) return 2*PI + val;
      return val;
}
double normD(double val)
{
      if (val < 0) return 360 + val;
      else return val;
}

Point3D Point3D::X(Point3D p)
{
	float X = y*p.z - p.y*z,
	      Y = -x*p.z + p.x*z,
	      Z = x*p.y - p.x*y;
	return Point3D(X,Y,Z);
}

Point3D * Point3D::Multiply(float  Matrix[][4])
{
	float temp[4] = {0};
	for(int i = 0;i<4;++i)
		temp[i] = x*Matrix[i][0] + y*Matrix[i][1] + z*Matrix[i][2];
	
    x = temp[0];y = temp[1]; z = temp[2];
    return this;
}

Point3D & Point3D::RotateXYZ(float Degx,float Degy,float Degz)
{
      float   alp = Rad(Degx),
                  bet = Rad(Degy),
                  gam = Rad(Degz);

      float MatALL[4][4] = {
            cos(bet)*cos(gam),     cos(gam)*sin(alp)*sin(bet)-cos(alp)*sin(gam),    cos(alp)*cos(gam)*sin(bet)+sin(alp)*sin(gam),   0,
            cos(bet)*sin(gam),      cos(alp)*cos(gam)+sin(alp)*sin(bet)*sin(gam),   -cos(gam)*sin(alp)+cos(alp)*sin(bet)*sin(gam),  0,
            -sin(bet),                      cos(bet)*sin(alp) ,                                                  cos(alp)*cos(bet),                                                0,
                  0       ,                                 0      ,                                                                      0,                                                                 1 };
      
      Multiply(MatALL);
      return *this;
}
float interiorClockwise(Point2D p1,Point2D p2,Point2D p3)
{
      Vector v1 = p2 - p1,v2 = p3 - p2;
      Point3D cross = v1.X(v2);
      
      v1 = v1*(-1);
      float angle = v1^v2;//smaller angle betw vectors

      if(cross.z < 0 ) return angle;
      else return 2*PI - angle;
}

void writeLine(Point2D p1,Point2D p2,std::ofstream &out,const char *color)
{	
      if( color == NULL) color = RED;
      
	out<<"\n\t<line x1 = \""<<p1.x
	<<"\" y1 = \""<<p1.y 
	<<"\" x2 = \""<<p2.x
	<<"\" y2 = \""<<p2.y
	<<"\" style=\"stroke:"<<color<<";stroke-width:2\" />\n";
}

void writeLines(PointList2D &P,std::ofstream &out,const char *color)
{
        for(std::vector<Point2D>::iterator it = P.begin();it != (P.end()-1);++it)
            writeLine(*it,*(it+1),out);
        //~ writeLine(P.front(),P.back(),out);            
}

void writePoint(Point2D P,std::ofstream &out,const char *color)
{
	out<<"\n\t<circle cx = \""<<P.x
	<<"\" cy = \""<<P.y 
	<<"\" r = \""<<2
	<<"\" stroke = \"black\" stroke-width = \"3\" />\n";
}

void writePoints(PointList2D &P,std::ofstream &out,const char *color)
{
        for(std::vector<Point2D>::iterator it = P.begin();it != P.end();++it)
            writePoint(*it,out);
}
void writePoly(PointList2D &P,std::ofstream &out,const char *color)
{
      for(PointList2D::iterator it = P.begin();it != (P.end()-1);++it)
            writeLine(*it,*(it+1),out,color);      
      writeLine(P.front(),P.back(),out,color);            
}

