
#ifndef __SMASHER__
#define __SMASHER__

class Cube;
class Rect;

class Smasher
{
      static bool Smash(Cube c1,Rect r1);
};
#endif
