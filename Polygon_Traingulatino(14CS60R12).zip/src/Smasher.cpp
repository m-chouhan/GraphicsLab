
#include "Smasher.h"

bool Smasher::Smash(Cube c1,Rect r1)
{
      return false;
}
